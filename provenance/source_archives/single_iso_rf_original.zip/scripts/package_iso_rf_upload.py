"""Create a clean, Linux-compatible source/data ZIP for school Jupyter."""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parents[1]
TOP_LEVEL = "single-iso-rf"


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = (args.output or ROOT.parent / f"single_iso_rf_upload_{timestamp}.zip").resolve()
    files = []
    for folder in ("data", "src", "scripts", "docs", "tests"):
        for path in (ROOT / folder).rglob("*"):
            if path.is_file() and "__pycache__" not in path.parts and path.suffix not in (".pyc", ".pyo"):
                files.append(path)
    for name in ("pyproject.toml", "README.md", "LICENSE", ".gitignore",
                 "FORMAL_VIOLATION_COUNT_EXPERIMENT.md", "DDP_ACCELERATION.md",
                 "bootstrap_conda_environment_setup.py"):
        files.append(ROOT / name)
    files.sort(key=lambda path: path.relative_to(ROOT).as_posix())
    manifest = []
    with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in files:
            relative = path.relative_to(ROOT).as_posix()
            manifest.append(f"{digest(path)}  {relative}")
            info = zipfile.ZipInfo(f"{TOP_LEVEL}/{relative}")
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())
        archive.writestr(f"{TOP_LEVEL}/UPLOAD_SHA256SUMS.txt", "\n".join(manifest) + "\n")
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        assert all("\\" not in name for name in archive.namelist())
        assert not any("/outputs/" in name or "/__pycache__/" in name for name in archive.namelist())
    checksum = digest(target)
    target.with_suffix(".zip.sha256").write_text(f"{checksum}  {target.name}\n", encoding="utf-8")
    print(f"PACKAGE={target}")
    print(f"SOURCE_FILE_COUNT={len(files)}")
    print(f"SIZE_MIB={target.stat().st_size / 1024**2:.3f}")
    print(f"SHA256={checksum}")
    print("POSIX_PATHS_OK")
    print("ISO_RF_UPLOAD_PACKAGE_OK")


if __name__ == "__main__":
    main()
