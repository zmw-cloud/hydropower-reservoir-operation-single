"""Plot a post-hoc, matched-reliability comparison of formal single-reservoir results.

This reporting script deliberately does not train or evaluate a policy.  It reads
the already persisted DDP, SDP, and ISO-SURF evaluation sweeps, selects the point
whose evaluation guarantee rate is nearest to a requested reference, and makes a
set of publication-style diagnostic figures.

Important
---------
The selection performed here is descriptive post-hoc matching on the evaluation
set.  It must not be described as independent validation-based lambda selection.
The current formal SDP and ISO-SURF artifacts were fitted with the complete
400-year training input and therefore do not contain an untouched validation
split from which lambda could be selected retrospectively.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime
from io import BytesIO
from pathlib import Path
import zipfile

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ALGORITHM_ORDER = ("DDP", "SDP", "ISO-SURF")
COLORS = {
    "DDP": "#1f77b4",
    "SDP": "#2ca02c",
    "ISO-SURF": "#d62728",
}
MARKERS = {"DDP": "o", "SDP": "s", "ISO-SURF": "D"}
FIRM_POWER_KW = 1_854_000.0
NORMAL_LEVEL_M = 1240.0
DEAD_LEVEL_M = 1166.0
MONTH_LABELS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

FONT_RC = {
    "font.family": "serif",
    "font.serif": ["Times New Roman", "DejaVu Serif"],
    "mathtext.fontset": "dejavuserif",
    "axes.unicode_minus": False,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
}
mpl.rcParams.update(FONT_RC)


@dataclass(frozen=True)
class EvaluationSource:
    algorithm: str
    container: Path
    summary_location: str
    trajectory_prefix: str
    is_zip: bool

    def description(self) -> str:
        if self.is_zip:
            return f"{self.container}::{self.summary_location}"
        return str(Path(self.summary_location))

    def read_summary(self) -> pd.DataFrame:
        if self.is_zip:
            with zipfile.ZipFile(self.container, "r") as archive:
                return pd.read_csv(BytesIO(archive.read(self.summary_location)))
        return pd.read_csv(Path(self.summary_location))

    def read_trajectory(self, penalty_lambda: float) -> pd.DataFrame:
        tag = format_lambda(penalty_lambda)
        basename = f"{self.trajectory_prefix}{tag}.csv"
        if self.is_zip:
            with zipfile.ZipFile(self.container, "r") as archive:
                matches = [name for name in archive.namelist()
                           if Path(name.replace("\\", "/")).name == basename]
                if len(matches) != 1:
                    raise FileNotFoundError(
                        f"Expected exactly one {basename} in {self.container}; "
                        f"found {len(matches)}"
                    )
                return pd.read_csv(BytesIO(archive.read(matches[0])))
        path = Path(self.summary_location).parent / basename
        if not path.is_file():
            raise FileNotFoundError(path)
        return pd.read_csv(path)


def format_lambda(value: float) -> str:
    number = float(value)
    if abs(number - round(number)) < 1e-9:
        return str(int(round(number)))
    return f"{number:g}"


def _newest(paths: list[Path]) -> Path:
    if not paths:
        raise FileNotFoundError("No candidate path was found")
    return max(paths, key=lambda path: path.stat().st_mtime)


def discover_source(
    outputs_root: Path,
    *,
    algorithm: str,
    folder: str,
    summary_basename: str,
    trajectory_prefix: str,
) -> EvaluationSource:
    search_root = outputs_root / folder
    if not search_root.is_dir():
        raise FileNotFoundError(search_root)

    summaries = list(search_root.rglob(summary_basename))
    if summaries:
        summary = _newest(summaries)
        return EvaluationSource(
            algorithm=algorithm,
            container=summary.parent,
            summary_location=str(summary),
            trajectory_prefix=trajectory_prefix,
            is_zip=False,
        )

    zip_candidates: list[tuple[Path, str]] = []
    for archive_path in search_root.rglob("*.zip"):
        try:
            with zipfile.ZipFile(archive_path, "r") as archive:
                for name in archive.namelist():
                    normalized = name.replace("\\", "/")
                    if Path(normalized).name == summary_basename:
                        zip_candidates.append((archive_path, name))
        except zipfile.BadZipFile:
            continue
    if not zip_candidates:
        raise FileNotFoundError(
            f"Could not find {summary_basename} below {search_root}"
        )
    archive_path, member = max(
        zip_candidates,
        key=lambda item: item[0].stat().st_mtime,
    )
    return EvaluationSource(
        algorithm=algorithm,
        container=archive_path,
        summary_location=member,
        trajectory_prefix=trajectory_prefix,
        is_zip=True,
    )


def discover_all_sources(outputs_root: Path) -> dict[str, EvaluationSource]:
    return {
        "DDP": discover_source(
            outputs_root,
            algorithm="DDP",
            folder="DDP",
            summary_basename="ddp_dense50_summary.csv",
            trajectory_prefix="ddp_eval_lambda_",
        ),
        "SDP": discover_source(
            outputs_root,
            algorithm="SDP",
            folder="SDP",
            summary_basename="sdp_dense50_summary.csv",
            trajectory_prefix="sdp_eval_lambda_",
        ),
        "ISO-SURF": discover_source(
            outputs_root,
            algorithm="ISO-SURF",
            folder="ISO",
            summary_basename="iso_surf_dense50_summary.csv",
            trajectory_prefix="iso_surf_eval_lambda_",
        ),
    }


def validate_summary(frame: pd.DataFrame, source: EvaluationSource) -> pd.DataFrame:
    required = {
        "lambda",
        "annual_generation_gwh",
        "guarantee_rate_pct",
        "violation_month_count",
    }
    missing = required.difference(frame.columns)
    if missing:
        raise KeyError(f"{source.description()} is missing {sorted(missing)}")
    result = frame.copy()
    for column in required:
        result[column] = pd.to_numeric(result[column], errors="raise")
    if result["lambda"].duplicated().any():
        raise ValueError(f"Duplicate lambda values in {source.description()}")
    if len(result) < 2:
        raise ValueError(f"Too few trade-off points in {source.description()}")
    return result.sort_values("lambda").reset_index(drop=True)


def select_nearest(summary: pd.DataFrame, target: float) -> pd.Series:
    ranked = summary.assign(
        distance_to_target_pct=(summary["guarantee_rate_pct"] - target).abs()
    ).sort_values(
        ["distance_to_target_pct", "annual_generation_gwh", "lambda"],
        ascending=[True, False, True],
    )
    return ranked.iloc[0]


def normalize_trajectory(
    frame: pd.DataFrame,
    algorithm: str,
    penalty_lambda: float,
) -> pd.DataFrame:
    required = {
        "Calendar_Year",
        "Calendar_Month",
        "Water_Level_m",
        "Power_kW",
        "Electricity_GWh",
        "Spill_Discharge_m3s",
        "Duration_Days",
        "Firm_Power_Deficit_kW",
        "Deficit_Energy_GWh",
        "Monthly_Max_Target_Level_m",
    }
    missing = required.difference(frame.columns)
    if missing:
        raise KeyError(f"{algorithm} trajectory is missing {sorted(missing)}")
    if len(frame) != 4800:
        raise ValueError(f"{algorithm} trajectory has {len(frame)} rows, expected 4800")

    result = pd.DataFrame({
        "algorithm": algorithm,
        "lambda": float(penalty_lambda),
        "year": pd.to_numeric(frame["Calendar_Year"], errors="raise").astype(int),
        "month": pd.to_numeric(frame["Calendar_Month"], errors="raise").astype(int),
        "level_m": pd.to_numeric(frame["Water_Level_m"], errors="raise"),
        "power_kw": pd.to_numeric(frame["Power_kW"], errors="raise"),
        "energy_gwh": pd.to_numeric(frame["Electricity_GWh"], errors="raise"),
        "spill_m3s": pd.to_numeric(frame["Spill_Discharge_m3s"], errors="raise"),
        "duration_days": pd.to_numeric(frame["Duration_Days"], errors="raise"),
        "deficit_kw": pd.to_numeric(frame["Firm_Power_Deficit_kW"], errors="raise"),
        "deficit_energy_gwh": pd.to_numeric(frame["Deficit_Energy_GWh"], errors="raise"),
        "monthly_max_level_m": pd.to_numeric(
            frame["Monthly_Max_Target_Level_m"], errors="raise"
        ),
    })
    if not np.isfinite(result.select_dtypes(include=[np.number])).all().all():
        raise ValueError(f"{algorithm} trajectory contains non-finite values")
    result["power_gw"] = result["power_kw"] / 1e6
    result["deficit_mw"] = result["deficit_kw"] / 1e3
    result["spill_volume_1e8_m3"] = (
        result["spill_m3s"] * result["duration_days"] * 86400.0 / 1e8
    )
    result["satisfied"] = result["power_kw"] >= FIRM_POWER_KW
    return result


def save_figure(fig: plt.Figure, output_dir: Path, stem: str, dpi: int) -> None:
    fig.savefig(output_dir / f"{stem}.pdf", bbox_inches="tight", format="pdf")
    fig.savefig(output_dir / f"{stem}.png", bbox_inches="tight", dpi=dpi)
    plt.close(fig)


def plot_selected_points(selected: pd.DataFrame, figures: Path, target: float, dpi: int) -> None:
    fig, ax = plt.subplots(figsize=(8.6, 5.2), dpi=dpi)
    for _, row in selected.iterrows():
        algorithm = row["algorithm"]
        x = row["guarantee_rate_pct"]
        y = row["annual_generation_gwh"] / 1000.0
        ax.scatter(x, y, s=95, marker=MARKERS[algorithm], color=COLORS[algorithm],
                   edgecolor="white", linewidth=0.8, zorder=3)
        ax.annotate(
            f"{algorithm}\n$\\lambda$={row['lambda']:g}",
            (x, y), xytext=(8, 7), textcoords="offset points",
            color=COLORS[algorithm], fontsize=11,
        )
    ax.axvline(target, color="0.45", linestyle=":", linewidth=1.8,
               label=f"{target:g}% comparison reference")
    ax.set_xlabel("Guarantee rate (%)", fontsize=13)
    ax.set_ylabel("Mean annual generation (TWh/yr)", fontsize=13)
    ax.tick_params(labelsize=11)
    ax.grid(True, alpha=0.28)
    ax.legend(frameon=False, loc="best", fontsize=10)
    fig.tight_layout()
    save_figure(fig, figures, "fig01_selected_generation_reliability", dpi)


def plot_tradeoff(
    summaries: dict[str, pd.DataFrame],
    selected: pd.DataFrame,
    figures: Path,
    target: float,
    dpi: int,
) -> None:
    fig, ax = plt.subplots(figsize=(9.2, 5.6), dpi=dpi)
    for algorithm in ALGORITHM_ORDER:
        frame = summaries[algorithm].sort_values("guarantee_rate_pct")
        ax.plot(
            frame["guarantee_rate_pct"],
            frame["annual_generation_gwh"] / 1000.0,
            color=COLORS[algorithm], linewidth=1.7, alpha=0.88,
            marker=MARKERS[algorithm], markersize=3.8, label=algorithm,
        )
        row = selected[selected["algorithm"] == algorithm].iloc[0]
        ax.scatter(
            row["guarantee_rate_pct"],
            row["annual_generation_gwh"] / 1000.0,
            s=145, marker=MARKERS[algorithm], color=COLORS[algorithm],
            edgecolor="black", linewidth=0.8, zorder=5,
        )
    ax.axvline(target, color="0.35", linestyle=":", linewidth=1.6)
    ax.set_xlabel("Guarantee rate (%)", fontsize=13)
    ax.set_ylabel("Mean annual generation (TWh/yr)", fontsize=13)
    ax.tick_params(labelsize=11)
    ax.grid(True, alpha=0.25)
    ax.legend(frameon=False, ncol=3, loc="best", fontsize=11)
    fig.tight_layout()
    save_figure(fig, figures, "fig02_generation_reliability_tradeoff", dpi)


def _grouped_monthly_boxplot(
    all_data: pd.DataFrame,
    value_column: str,
    ylabel: str,
    figures: Path,
    stem: str,
    dpi: int,
    reference_line: float | None = None,
) -> None:
    fig, ax = plt.subplots(figsize=(13.2, 6.0), dpi=dpi)
    centers = np.arange(1, 13, dtype=float)
    offsets = {"DDP": -0.24, "SDP": 0.0, "ISO-SURF": 0.24}
    for algorithm in ALGORITHM_ORDER:
        values = [
            all_data.loc[
                (all_data["algorithm"] == algorithm) & (all_data["month"] == month),
                value_column,
            ].to_numpy(dtype=float)
            for month in range(1, 13)
        ]
        positions = centers + offsets[algorithm]
        box = ax.boxplot(
            values,
            positions=positions,
            widths=0.20,
            patch_artist=True,
            showfliers=True,
            flierprops={"marker": ".", "markersize": 1.8, "alpha": 0.35,
                        "markerfacecolor": COLORS[algorithm],
                        "markeredgecolor": COLORS[algorithm]},
            medianprops={"color": "black", "linewidth": 1.0},
        )
        for patch in box["boxes"]:
            patch.set_facecolor(COLORS[algorithm])
            patch.set_alpha(0.58)
        means = [float(np.mean(value)) for value in values]
        ax.scatter(positions, means, s=18, facecolor="white",
                   edgecolor=COLORS[algorithm], linewidth=1.2, zorder=4)
    if reference_line is not None:
        ax.axhline(reference_line, color="#2ca02c", linestyle="--", linewidth=1.4,
                   label="Firm-power requirement")
    handles = [mpl.patches.Patch(facecolor=COLORS[name], alpha=0.58, label=name)
               for name in ALGORITHM_ORDER]
    if reference_line is not None:
        handles.append(mpl.lines.Line2D([], [], color="#2ca02c", linestyle="--",
                                       label="Firm-power requirement"))
    ax.legend(handles=handles, frameon=False, ncol=len(handles),
              loc="upper center", bbox_to_anchor=(0.5, 1.12), fontsize=10)
    ax.set_xticks(centers)
    ax.set_xticklabels(MONTH_LABELS)
    ax.set_xlim(0.55, 12.45)
    ax.set_xlabel("Calendar month", fontsize=13)
    ax.set_ylabel(ylabel, fontsize=13)
    ax.tick_params(labelsize=10)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    save_figure(fig, figures, stem, dpi)


def plot_duration_curves(all_data: pd.DataFrame, figures: Path, dpi: int) -> None:
    for column, ylabel, stem, reference in (
        ("power_gw", "Power (GW)", "fig03_power_duration", FIRM_POWER_KW / 1e6),
        ("deficit_mw", "Firm-power deficit (MW)", "fig04_deficit_duration", None),
    ):
        fig, ax = plt.subplots(figsize=(9.4, 5.6), dpi=dpi)
        for algorithm in ALGORITHM_ORDER:
            values = np.sort(
                all_data.loc[all_data["algorithm"] == algorithm, column]
                .to_numpy(dtype=float)
            )[::-1]
            exceedance = np.arange(1, len(values) + 1) / len(values) * 100.0
            ax.plot(exceedance, values, color=COLORS[algorithm], linewidth=1.8,
                    label=algorithm)
        if reference is not None:
            ax.axhline(reference, color="#2ca02c", linestyle="--", linewidth=1.4,
                       label="Firm-power requirement")
        ax.set_xlabel("Exceedance probability (%)", fontsize=13)
        ax.set_ylabel(ylabel, fontsize=13)
        ax.tick_params(labelsize=11)
        ax.grid(True, alpha=0.25)
        ax.legend(frameon=False, fontsize=10)
        fig.tight_layout()
        save_figure(fig, figures, stem, dpi)


def plot_monthly_levels(all_data: pd.DataFrame, figures: Path, dpi: int) -> None:
    fig, ax = plt.subplots(figsize=(10.5, 5.8), dpi=dpi)
    x = np.arange(1, 13)
    for algorithm in ALGORITHM_ORDER:
        sub = all_data[all_data["algorithm"] == algorithm]
        grouped = sub.groupby("month")["level_m"]
        mean = grouped.mean().reindex(x).to_numpy(dtype=float)
        p10 = grouped.quantile(0.10).reindex(x).to_numpy(dtype=float)
        p90 = grouped.quantile(0.90).reindex(x).to_numpy(dtype=float)
        ax.plot(x, mean, color=COLORS[algorithm], marker=MARKERS[algorithm],
                linewidth=1.8, markersize=5, label=f"{algorithm} mean (P10-P90)")
        ax.fill_between(x, p10, p90, color=COLORS[algorithm], alpha=0.12)
    limits = (
        all_data.groupby("month")["monthly_max_level_m"].median()
        .reindex(x).to_numpy(dtype=float)
    )
    ax.axhline(NORMAL_LEVEL_M, color="black", linestyle="--", linewidth=1.2,
               label="Normal water level")
    ax.axhline(DEAD_LEVEL_M, color="0.4", linestyle=":", linewidth=1.2,
               label="Dead water level")
    ax.step(x, limits, where="mid", color="#e377c2", linestyle="-.", linewidth=1.4,
            label="Monthly maximum target level")
    ax.set_xticks(x)
    ax.set_xticklabels(MONTH_LABELS)
    ax.set_xlabel("Calendar month", fontsize=13)
    ax.set_ylabel("End-of-month water level (m)", fontsize=13)
    ax.tick_params(labelsize=10)
    ax.grid(True, alpha=0.25)
    ax.legend(frameon=False, ncol=3, loc="upper center",
              bbox_to_anchor=(0.5, 1.18), fontsize=9)
    fig.tight_layout()
    save_figure(fig, figures, "fig05_monthly_level_mean_p10_p90", dpi)


def plot_monthly_mean_spill(all_data: pd.DataFrame, figures: Path, dpi: int) -> None:
    fig, ax = plt.subplots(figsize=(10.5, 5.6), dpi=dpi)
    x = np.arange(1, 13)
    width = 0.24
    for index, algorithm in enumerate(ALGORITHM_ORDER):
        means = (
            all_data[all_data["algorithm"] == algorithm]
            .groupby("month")["spill_volume_1e8_m3"].mean()
            .reindex(x).to_numpy(dtype=float)
        )
        ax.bar(x + (index - 1) * width, means, width=width,
               color=COLORS[algorithm], alpha=0.72, label=algorithm)
    ax.set_xticks(x)
    ax.set_xticklabels(MONTH_LABELS)
    ax.set_xlabel("Calendar month", fontsize=13)
    ax.set_ylabel(r"Mean spill volume ($10^8$ m$^3$/month)", fontsize=13)
    ax.tick_params(labelsize=10)
    ax.grid(axis="y", alpha=0.25)
    ax.legend(frameon=False, ncol=3, fontsize=10)
    fig.tight_layout()
    save_figure(fig, figures, "fig06_monthly_mean_spill_volume", dpi)


def plot_annual_generation(all_data: pd.DataFrame, figures: Path, dpi: int) -> pd.DataFrame:
    annual = (
        all_data.groupby(["algorithm", "year"], as_index=False)["energy_gwh"]
        .sum()
        .rename(columns={"energy_gwh": "annual_generation_gwh"})
    )
    annual["annual_generation_twh"] = annual["annual_generation_gwh"] / 1000.0
    values = [annual.loc[annual["algorithm"] == name, "annual_generation_twh"]
              .to_numpy(dtype=float) for name in ALGORITHM_ORDER]
    fig, ax = plt.subplots(figsize=(8.2, 5.8), dpi=dpi)
    box = ax.boxplot(values, tick_labels=ALGORITHM_ORDER, patch_artist=True,
                     showfliers=True, medianprops={"color": "black", "linewidth": 1.3})
    for patch, algorithm in zip(box["boxes"], ALGORITHM_ORDER):
        patch.set_facecolor(COLORS[algorithm])
        patch.set_alpha(0.62)
    ax.set_xlabel("Algorithm", fontsize=13)
    ax.set_ylabel("Annual generation (TWh/yr)", fontsize=13)
    ax.tick_params(labelsize=11)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    save_figure(fig, figures, "fig07_annual_generation_boxplot", dpi)
    return annual


def export_monthly_statistics(all_data: pd.DataFrame) -> pd.DataFrame:
    return (
        all_data.groupby(["algorithm", "month"], as_index=False)
        .agg(
            power_mean_gw=("power_gw", "mean"),
            power_p10_gw=("power_gw", lambda x: x.quantile(0.10)),
            power_p90_gw=("power_gw", lambda x: x.quantile(0.90)),
            level_mean_m=("level_m", "mean"),
            level_p10_m=("level_m", lambda x: x.quantile(0.10)),
            level_p90_m=("level_m", lambda x: x.quantile(0.90)),
            spill_mean_1e8_m3=("spill_volume_1e8_m3", "mean"),
            deficit_energy_mean_gwh=("deficit_energy_gwh", "mean"),
        )
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", type=float, default=80.0)
    parser.add_argument("--dpi", type=int, default=600)
    parser.add_argument("--outputs-root", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    project_root = Path(__file__).resolve().parents[1]
    outputs_root = (args.outputs_root or project_root / "outputs").resolve()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = (
        args.output_dir
        or outputs_root / f"comparison_single_target{args.target:g}_evaluation_nearest_{timestamp}"
    ).resolve()
    figures = output_dir / "figures"
    tables = output_dir / "tables"
    figures.mkdir(parents=True, exist_ok=False)
    tables.mkdir(parents=True, exist_ok=False)

    sources = discover_all_sources(outputs_root)
    summaries: dict[str, pd.DataFrame] = {}
    selected_rows: list[dict] = []
    trajectories: list[pd.DataFrame] = []

    for algorithm in ALGORITHM_ORDER:
        source = sources[algorithm]
        summary = validate_summary(source.read_summary(), source)
        summaries[algorithm] = summary
        choice = select_nearest(summary, args.target)
        trajectory = normalize_trajectory(
            source.read_trajectory(float(choice["lambda"])),
            algorithm,
            float(choice["lambda"]),
        )
        computed_rate = float(trajectory["satisfied"].mean() * 100.0)
        if not np.isclose(computed_rate, float(choice["guarantee_rate_pct"]), atol=1e-8):
            raise ValueError(
                f"{algorithm} summary/trajectory guarantee-rate mismatch: "
                f"{choice['guarantee_rate_pct']} vs {computed_rate}"
            )
        selected_rows.append({
            "algorithm": algorithm,
            "lambda": float(choice["lambda"]),
            "selection_basis": "posthoc_evaluation_nearest_target",
            "target_guarantee_rate_pct": float(args.target),
            "guarantee_rate_pct": float(choice["guarantee_rate_pct"]),
            "absolute_distance_to_target_pct": abs(
                float(choice["guarantee_rate_pct"]) - float(args.target)
            ),
            "annual_generation_gwh": float(choice["annual_generation_gwh"]),
            "violation_month_count": int(choice["violation_month_count"]),
            "source": source.description(),
        })
        trajectories.append(trajectory)
        print(
            f"Selected {algorithm}: lambda={choice['lambda']:g}, "
            f"guarantee={choice['guarantee_rate_pct']:.6f}%, "
            f"annual_generation={choice['annual_generation_gwh']:.6f} GWh/yr"
        )

    selected = pd.DataFrame(selected_rows)
    ddp = selected[selected["algorithm"] == "DDP"].iloc[0]
    selected["generation_gap_to_selected_ddp_gwh"] = (
        float(ddp["annual_generation_gwh"]) - selected["annual_generation_gwh"]
    )
    selected["guarantee_rate_difference_to_selected_ddp_pct"] = (
        selected["guarantee_rate_pct"] - float(ddp["guarantee_rate_pct"])
    )
    all_data = pd.concat(trajectories, ignore_index=True)

    tradeoff = pd.concat(
        [frame.assign(algorithm=algorithm) for algorithm, frame in summaries.items()],
        ignore_index=True,
    )
    selected.to_csv(tables / "selected_performance_points.csv", index=False,
                    encoding="utf-8-sig")
    tradeoff.to_csv(tables / "tradeoff_points.csv", index=False,
                    encoding="utf-8-sig")
    export_monthly_statistics(all_data).to_csv(
        tables / "monthly_statistics.csv", index=False, encoding="utf-8-sig"
    )

    plot_selected_points(selected, figures, args.target, args.dpi)
    plot_tradeoff(summaries, selected, figures, args.target, args.dpi)
    _grouped_monthly_boxplot(
        all_data, "power_gw", "Power (GW)", figures,
        "fig03_monthly_power_boxplots", args.dpi,
        reference_line=FIRM_POWER_KW / 1e6,
    )
    plot_duration_curves(all_data, figures, args.dpi)
    plot_monthly_levels(all_data, figures, args.dpi)
    plot_monthly_mean_spill(all_data, figures, args.dpi)
    _grouped_monthly_boxplot(
        all_data, "spill_volume_1e8_m3",
        r"Spill volume ($10^8$ m$^3$/month)", figures,
        "fig06_monthly_spill_boxplots", args.dpi,
    )
    annual = plot_annual_generation(all_data, figures, args.dpi)
    annual.to_csv(tables / "annual_generation_by_year.csv", index=False,
                  encoding="utf-8-sig")
    annual.groupby("algorithm", as_index=False)["annual_generation_twh"].agg(
        ["mean", "std", "min", "median", "max"]
    ).to_csv(tables / "annual_generation_statistics.csv", encoding="utf-8-sig")

    readme = f"""Single-reservoir matched-reliability comparison

Target guarantee rate: {args.target:g}%
Algorithms: DDP, SDP, ISO-SURF
Selection rule: nearest guarantee rate on the persisted 400-year evaluation sweep.

IMPORTANT: this is a descriptive post-hoc matched-reliability comparison.  It is
not independent validation-based lambda selection.  The current formal SDP and
ISO-SURF policies were fitted using the complete 400-year training input, so their
lambda values cannot be retrospectively selected on an untouched subset of that
same training input.  Formal validation selection would require retraining all
candidate policies on the first 320 years, selecting on the final 80 training
years, then retraining the selected candidate on all 400 training years.
"""
    (output_dir / "SELECTION_PROTOCOL.txt").write_text(readme, encoding="utf-8")

    print("\nSelected points:")
    print(selected.to_string(index=False))
    print(f"\nOutput directory: {output_dir}")
    print(f"Figures: {len(list(figures.glob('*.png')))} PNG + "
          f"{len(list(figures.glob('*.pdf')))} PDF")
    print("SINGLE_TARGET_RELIABILITY_COMPARISON_OK")


if __name__ == "__main__":
    main()
