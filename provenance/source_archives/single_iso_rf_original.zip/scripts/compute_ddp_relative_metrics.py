"""Attach same-problem DDP-relative external metrics to method summary JSON files."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from reservoir_benchmark.evaluation.common_metrics import ddp_relative_metrics


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ddp-summary", type=Path, required=True)
    parser.add_argument("--method-summary", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    ddp = json.loads(args.ddp_summary.read_text(encoding="utf-8"))
    rows = []
    for path in args.method_summary:
        summary = json.loads(path.read_text(encoding="utf-8"))
        rows.append(
            {
                "summary_path": str(path),
                "method": summary.get("method"),
                **ddp_relative_metrics(summary, ddp),
            }
        )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(
            {
                "ddp_summary_path": str(args.ddp_summary),
                "comparisons": rows,
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
