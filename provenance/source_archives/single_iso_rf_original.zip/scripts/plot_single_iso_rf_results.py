"""Plot saved ISO-RF validation trade-off or the selected independent evaluation."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from reservoir_benchmark.shared.project_paths import get_formal_algorithm_dir
from reservoir_benchmark.policy_generation.iso_rf.workflow import read_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("validation", "evaluation"))
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--dpi", type=int, default=600)
    args = parser.parse_args()
    root = args.output_root or get_formal_algorithm_dir("iso_rf")
    if args.stage == "validation":
        frame = pd.read_csv(root / "lambda_scan" / "lambda_scan_results.csv").sort_values("lambda")
        x = frame["guarantee_rate"] * 100
        y = frame["mean_annual_generation_gwh"] / 1000
    else:
        selection = read_json(root / "selection" / "selected_lambda.json")
        frame = pd.read_csv(root / "evaluation" / "iso_rf_evaluation_summary.csv")
        if len(frame) != 1 or float(frame.iloc[0]["lambda"]) != selection["lambda"]:
            raise ValueError("Evaluation table does not match the frozen validation selection")
        x = frame["guarantee_rate_pct"]
        y = frame["annual_generation_gwh"] / 1000
    output = root / "figures"
    output.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8.8, 5.6))
    ax.plot(x, y, color="#d62728", marker="D", linewidth=1.6,
            linestyle="-" if args.stage == "validation" else "none",
            label=f"ISO-RF ({args.stage})")
    selection_path = root / "selection" / "selected_lambda.json"
    if selection_path.is_file():
        selection = read_json(selection_path)
        ax.axvline(selection["target_guarantee_rate"] * 100, color="0.5", linestyle=":")
        if args.stage == "validation":
            chosen = frame.loc[frame["lambda"] == selection["lambda"]]
            if len(chosen) != 1:
                raise ValueError("Selected lambda is absent/duplicated in validation table")
            ax.scatter(chosen["guarantee_rate"] * 100,
                       chosen["mean_annual_generation_gwh"] / 1000,
                       s=100, marker="D", color="#d62728", edgecolor="black", zorder=4)
    ax.set_xlabel("Guarantee rate (%)")
    ax.set_ylabel("Mean annual generation (TWh/yr)")
    ax.grid(True, alpha=0.25)
    ax.legend(frameon=False)
    fig.tight_layout()
    stem = f"iso_rf_{args.stage}_generation_reliability"
    for extension in ("png", "pdf"):
        fig.savefig(output / f"{stem}.{extension}", dpi=args.dpi, bbox_inches="tight")
    plt.close(fig)
    print(f"FIGURE={output / (stem + '.png')}")
    print("ISO_RF_PLOT_OK")


if __name__ == "__main__":
    main()
