"""Optional short equivalence check; never writes policy/evaluation results."""
from pathlib import Path
import os
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import numpy as np
from _ddp_scalar_reference import ReservoirOperation as ScalarDDP
from reservoir_benchmark.policy_generation.ddp.ddp_solver import ReservoirOperation
from reservoir_benchmark.shared.io_utils import load_monthly_inflows_with_calendar, calendar_days_matrix
from reservoir_benchmark.shared.reservoir_model import SharedReservoirModel


def main():
    frame, years = load_monthly_inflows_with_calendar(ROOT / "data/SynMonthlyInflow_evaluation.xlsx")
    inflows = frame.iloc[:2].to_numpy(dtype=float)
    days = calendar_days_matrix(years[:2])
    model = SharedReservoirModel(data_dir=ROOT / "data")
    reference = ScalarDDP(model, inflows, month_days=days)
    expected = {}
    started = time.perf_counter()
    for lam in (0.0, 20.0):
        expected[lam] = reference.optimize(lam)
    scalar_seconds = time.perf_counter() - started
    print(f"SCALAR_REFERENCE_SECONDS={scalar_seconds:.3f}", flush=True)
    for workers in (1, 4):
        os.environ["DDP_NUM_WORKERS"] = str(workers)
        solver = ReservoirOperation(model, inflows, month_days=days)
        started = time.perf_counter()
        try:
            for lam in (0.0, 20.0):
                actual = solver.optimize(lam)
                reference_result = expected[lam]
                assert len(actual) == len(reference_result)
                # Values allow floating-point roundoff, policies must be exact.
                np.testing.assert_allclose(actual[0], reference_result[0], rtol=1e-12, atol=1e-7)
                np.testing.assert_array_equal(actual[1], reference_result[1])
                for index in range(2, len(actual)):
                    np.testing.assert_allclose(actual[index], reference_result[index], rtol=1e-12, atol=1e-8)
                assert actual[1].dtype == np.uint16
                assert np.isclose(actual[2][-1], model.terminal_level)
                assert np.all(np.asarray(actual[2]) <= np.asarray(actual[12]) + 1e-8)
                print(f"EQUIVALENCE_OK workers={workers} lambda={lam:g}", flush=True)
            print(f"ACCELERATED_SECONDS workers={workers}: {time.perf_counter() - started:.3f}")
        finally:
            solver.clear_transition_cache()
    print("DDP_ACCELERATION_CHECK_OK")


if __name__ == "__main__":
    main()
