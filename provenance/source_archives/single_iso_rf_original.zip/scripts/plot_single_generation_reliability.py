"""Plot guarantee rate (x) against mean annual generation (y).

DDP/SDP/ISO use existing independent evaluation results. By default, DQN uses
the penalty-scan validation metrics of the best validation checkpoint per seed.
No policy training or simulation is performed.
"""

from __future__ import annotations

import argparse
from datetime import datetime
from io import BytesIO
import hashlib
import json
from pathlib import Path
import re
import zipfile

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from plot_single_target_reliability_comparison import (
    EvaluationSource,
    discover_all_sources,
    format_lambda,
    select_nearest,
    validate_summary,
)


ORDER = ("DDP", "SDP", "ISO-SURF", "DQN")
COLORS = {"DDP": "#1f77b4", "SDP": "#2ca02c",
          "ISO-SURF": "#d62728", "DQN": "#9467bd"}
MARKERS = {"DDP": "o", "SDP": "s", "ISO-SURF": "D", "DQN": "^"}
DQN_FILE = re.compile(r"^dqn_eval_lambda_([0-9.]+)_seed_(\d+)\.json$")
DQN_VALIDATION_SEEDS = "tables/LAMBDA_SCAN_SEED_RESULTS.csv"
DQN_VALIDATION_SUMMARY = "tables/LAMBDA_SCAN_SUMMARY.csv"


def expected_hashes(project: Path) -> tuple[str, str]:
    data = project / "data"
    data_hash = hashlib.sha256(
        (data / "SynMonthlyInflow_evaluation.xlsx").read_bytes()
    ).hexdigest()
    digest = hashlib.sha256()
    for name in ("reservoir_settings.txt", "level_storage_curve.csv",
                 "tailwater_discharge_curve.csv"):
        digest.update(name.encode())
        digest.update((data / name).read_bytes())
    return data_hash, digest.hexdigest()


def check_evaluation(item: dict, source: str, hashes: tuple[str, str]) -> None:
    expected = {
        "objective_version": "single_violation_count_v1",
        "penalty_definition": "generation_gwh_minus_lambda_per_failed_reservoir_month",
        "data_split": "evaluation",
        "months": 4800,
        "data_hash": hashes[0],
        "physics_hash": hashes[1],
    }
    for key, value in expected.items():
        if item.get(key) != value:
            raise ValueError(f"Incompatible evaluation {source}: {key}")
    for key in ("lambda", "mean_annual_generation_gwh", "guarantee_rate"):
        if not np.isfinite(float(item[key])):
            raise ValueError(f"Non-finite {key}: {source}")
    if not 0 <= float(item["guarantee_rate"]) <= 1:
        raise ValueError(f"Invalid guarantee rate: {source}")


def read_classical_json(source: EvaluationSource, penalty: float) -> tuple[dict, str]:
    basename = f"{source.trajectory_prefix}{format_lambda(penalty)}.json"
    if source.is_zip:
        with zipfile.ZipFile(source.container) as archive:
            parent = Path(source.summary_location.replace("\\", "/")).parent
            matches = [name for name in archive.namelist()
                       if Path(name.replace("\\", "/")) == parent / basename]
            if len(matches) != 1:
                raise ValueError(f"Expected one companion {basename} in {source.container}")
            return json.loads(archive.read(matches[0]).decode("utf-8-sig")), (
                f"{source.container}::{matches[0]}"
            )
    path = Path(source.summary_location).parent / basename
    return json.loads(path.read_text(encoding="utf-8-sig")), str(path)


def load_classical(outputs: Path, hashes: tuple[str, str]) -> pd.DataFrame:
    rows = []
    for algorithm, source in discover_all_sources(outputs).items():
        summary = validate_summary(source.read_summary(), source)
        for _, row in summary.iterrows():
            item, location = read_classical_json(source, float(row["lambda"]))
            check_evaluation(item, location, hashes)
            if not np.isclose(float(item["lambda"]), float(row["lambda"]), rtol=0, atol=1e-9):
                raise ValueError(f"Lambda mismatch: {location}")
            generation = float(item["mean_annual_generation_gwh"])
            guarantee = 100 * float(item["guarantee_rate"])
            if not np.isclose(generation, float(row["annual_generation_gwh"]), rtol=0, atol=1e-6):
                raise ValueError(f"Generation summary mismatch: {location}")
            if not np.isclose(guarantee, float(row["guarantee_rate_pct"]), rtol=0, atol=1e-8):
                raise ValueError(f"Guarantee summary mismatch: {location}")
            rows.append({
                "algorithm": algorithm,
                "lambda": float(item["lambda"]),
                "annual_generation_gwh": generation,
                "guarantee_rate_pct": guarantee,
                "generation_std_gwh": 0.0,
                "guarantee_std_pct": 0.0,
                "seed_count": 1,
                "data_split": "evaluation",
                "months_per_seed": int(item["months"]),
                "source": location,
            })
    return pd.DataFrame(rows)


def find_dqn_source(outputs: Path, supplied: Path | None,
                    split: str = "validation") -> Path | None:
    if supplied is not None:
        return supplied.resolve()
    if split == "validation":
        root = outputs / "DQN"
        found = []
        if root.is_dir():
            found.extend(p.parent.parent for p in root.rglob("LAMBDA_SCAN_SEED_RESULTS.csv"))
            for package in root.rglob("*.zip"):
                with zipfile.ZipFile(package) as archive:
                    if DQN_VALIDATION_SEEDS in archive.namelist():
                        found.append(package)
        if len(found) != 1:
            raise ValueError(
                f"Expected one DQN validation scan source, found {len(found)}. "
                "Use --dqn-source to specify its ZIP or extracted directory."
            )
        return found[0]
    folders = [outputs / "DQN",
               outputs / "violation_count_penalty" / "xiaowan_single_violation_count_v1"
               / "dqn" / "evaluation"]
    found = []
    for folder in folders:
        if not folder.is_dir():
            continue
        loose = [path for path in folder.rglob("*.json") if DQN_FILE.fullmatch(path.name)]
        if loose:
            found.append(folder)
            continue
        for path in folder.rglob("*.zip"):
            with zipfile.ZipFile(path) as archive:
                if any(DQN_FILE.fullmatch(Path(name.replace("\\", "/")).name)
                       for name in archive.namelist()):
                    found.append(path)
    if len(found) > 1:
        raise ValueError("Multiple DQN result sources found; use --dqn-source to choose one")
    return found[0] if found else None


def read_dqn_records(source: Path) -> list[tuple[str, dict]]:
    if source.is_file() and source.suffix.lower() == ".zip":
        with zipfile.ZipFile(source) as archive:
            return [
                (f"{source}::{name}", json.loads(archive.read(name).decode("utf-8-sig")))
                for name in archive.namelist()
                if DQN_FILE.fullmatch(Path(name.replace("\\", "/")).name)
            ]
    if source.is_dir():
        return [(str(path), json.loads(path.read_text(encoding="utf-8-sig")))
                for path in source.rglob("*.json") if DQN_FILE.fullmatch(path.name)]
    raise ValueError(f"DQN source must be an evaluation directory or ZIP: {source}")


def aggregate_dqn(records: list[tuple[str, dict]], hashes: tuple[str, str]) -> tuple[pd.DataFrame, pd.DataFrame]:
    if not records:
        raise ValueError("No dqn_eval_lambda_*_seed_*.json final evaluation records found")
    rows = []
    for source, item in records:
        check_evaluation(item, source, hashes)
        if item.get("evaluation_split") != "independent_400_year_evaluation":
            raise ValueError(f"DQN record is not independent evaluation: {source}")
        if item.get("checkpoint_metadata", {}).get("checkpoint_role") != "final":
            raise ValueError(f"DQN record was not generated from a final checkpoint: {source}")
        if item.get("evaluation_greedy") is not True or item.get("evaluation_learning") is not False:
            raise ValueError(f"DQN evaluation protocol is incompatible: {source}")
        rows.append({
            "lambda": float(item["lambda"]),
            "seed": int(item["seed"]),
            "annual_generation_gwh": float(item["mean_annual_generation_gwh"]),
            "guarantee_rate_pct": 100 * float(item["guarantee_rate"]),
            "data_split": "evaluation", "months_per_seed": int(item["months"]),
            "source": source,
        })
    seeds = pd.DataFrame(rows)
    if seeds.duplicated(["lambda", "seed"]).any():
        raise ValueError("Duplicate DQN lambda/seed results; select a single result package")
    grouped_rows = []
    for penalty, group in seeds.groupby("lambda", sort=True):
        if set(group["seed"]) != {1, 42, 100}:
            raise ValueError(f"DQN lambda={penalty:g} requires exactly seeds 1,42,100")
        grouped_rows.append({
            "algorithm": "DQN", "lambda": penalty,
            "annual_generation_gwh": group["annual_generation_gwh"].mean(),
            "guarantee_rate_pct": group["guarantee_rate_pct"].mean(),
            "generation_std_gwh": group["annual_generation_gwh"].std(ddof=1),
            "guarantee_std_pct": group["guarantee_rate_pct"].std(ddof=1),
            "seed_count": len(group), "source": " | ".join(group["source"]),
            "data_split": "evaluation", "months_per_seed": 4800,
        })
    return pd.DataFrame(grouped_rows), seeds


def load_dqn_validation(source: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Read paired scan tables and verify their seed aggregates and 80-year rates."""
    if source.is_file() and source.suffix.lower() == ".zip":
        with zipfile.ZipFile(source) as archive:
            seeds = pd.read_csv(BytesIO(archive.read(DQN_VALIDATION_SEEDS)))
            summary = pd.read_csv(BytesIO(archive.read(DQN_VALIDATION_SUMMARY)))
        location = f"{source}::{DQN_VALIDATION_SEEDS}"
    elif source.is_dir():
        seeds = pd.read_csv(source / DQN_VALIDATION_SEEDS)
        summary = pd.read_csv(source / DQN_VALIDATION_SUMMARY)
        location = str(source / DQN_VALIDATION_SEEDS)
    else:
        raise ValueError(f"DQN validation source must be a scan ZIP or directory: {source}")

    required = ("lambda", "seed", "best_episode", "best_validation_score",
                "annual_generation_gwh", "guarantee_rate_pct", "violation_month_count")
    for column in required:
        seeds[column] = pd.to_numeric(seeds[column], errors="raise")
    if seeds.empty or not np.isfinite(seeds[list(required)].to_numpy()).all():
        raise ValueError("DQN validation seed metrics are empty or non-finite")
    if seeds.duplicated(["lambda", "seed"]).any() or summary["lambda"].duplicated().any():
        raise ValueError("Duplicate DQN validation lambda/seed or summary lambda")
    if not seeds["guarantee_rate_pct"].between(0, 100).all():
        raise ValueError("Invalid DQN validation guarantee rates")
    if not seeds["violation_month_count"].between(0, 960).all():
        raise ValueError("Invalid DQN validation failed-month count")
    if not np.allclose(seeds["guarantee_rate_pct"],
                       100 * (1 - seeds["violation_month_count"] / 960),
                       rtol=0, atol=1e-8):
        raise ValueError("DQN validation rates do not match the 960-month counts")
    score = seeds["annual_generation_gwh"] - (
        seeds["lambda"] * seeds["violation_month_count"] / 80.0
    )
    if not np.allclose(score, seeds["best_validation_score"], rtol=0, atol=1e-6):
        raise ValueError("DQN seed metrics do not match their best validation objective")
    if set(summary["lambda"]) != set(seeds["lambda"]):
        raise ValueError("DQN seed and aggregate tables cover different penalties")

    rows = []
    for penalty, group in seeds.groupby("lambda", sort=True):
        if set(group["seed"]) != {1, 42, 100}:
            raise ValueError(f"DQN lambda={penalty:g} requires seeds 1,42,100")
        metrics = {
            "annual_generation_gwh": group["annual_generation_gwh"].mean(),
            "guarantee_rate_pct": group["guarantee_rate_pct"].mean(),
            "generation_std_gwh": group["annual_generation_gwh"].std(ddof=1),
            "guarantee_std_pct": group["guarantee_rate_pct"].std(ddof=1),
        }
        aggregate = summary.loc[summary["lambda"] == penalty].iloc[0]
        names = {"annual_generation_gwh": "mean_annual_generation_gwh",
                 "guarantee_rate_pct": "mean_guarantee_rate_pct",
                 "generation_std_gwh": "generation_std_gwh",
                 "guarantee_std_pct": "guarantee_std_pct"}
        for key, summary_column in names.items():
            if not np.isclose(metrics[key], float(aggregate[summary_column]),
                              rtol=0, atol=1e-6):
                raise ValueError(f"DQN validation aggregate mismatch: {penalty:g}, {key}")
        if int(aggregate["seed_count"]) != len(group):
            raise ValueError(f"DQN validation seed count mismatch: {penalty:g}")
        rows.append({"algorithm": "DQN", "lambda": float(penalty), **metrics,
                     "seed_count": len(group), "data_split": "validation",
                     "months_per_seed": 960, "source": location})
    seeds = seeds.assign(data_split="validation", months_per_seed=960,
                         source_archive=location)
    return pd.DataFrame(rows), seeds


def draw(points: pd.DataFrame, target: float | None, unit: str, dpi: int,
         output: Path, dqn_error_bars: bool = False) -> pd.DataFrame:
    scale = 1000.0 if unit == "TWh" else 1.0
    fig, ax = plt.subplots(figsize=(9.2, 5.8))
    highlighted = []
    for algorithm in ORDER:
        group = points[points["algorithm"] == algorithm].sort_values("lambda")
        if group.empty:
            continue
        # Connect in lambda order, preserving any genuine nonmonotonic response.
        label = "ISO" if algorithm == "ISO-SURF" else algorithm
        if algorithm == "DQN":
            split = group["data_split"].iloc[0]
            label = f"DQN {split} (3-seed mean)"
        style = {"color": COLORS[algorithm], "marker": MARKERS[algorithm],
                 "markersize": 4, "linewidth": 1.7, "label": label}
        x = group["guarantee_rate_pct"].to_numpy()
        y = group["annual_generation_gwh"].to_numpy() / scale
        if algorithm == "DQN" and dqn_error_bars:
            ax.errorbar(x, y, xerr=group["guarantee_std_pct"].to_numpy(),
                        yerr=group["generation_std_gwh"].to_numpy() / scale,
                        capsize=3, elinewidth=1.0,
                        linestyle="-" if len(group) > 1 else "none", **style)
        else:
            ax.plot(x, y, linestyle="-", **style)
            if target is not None and algorithm != "DQN":
                choice = select_nearest(group, target).to_dict()
                choice["selection_basis"] = "posthoc_evaluation_nearest_target"
                highlighted.append(choice)
                ax.scatter(choice["guarantee_rate_pct"],
                           choice["annual_generation_gwh"] / scale,
                           s=95, marker=MARKERS[algorithm], color=COLORS[algorithm],
                           edgecolor="black", linewidth=0.9, zorder=5)
    references = (80.0, 90.0) if target is None else (target,)
    for reference in references:
        ax.axvline(reference, color="0.45", linestyle=":" if reference == 80 else "--",
                   linewidth=1.2, label=f"{reference:g}% reference")
    ax.set_xlabel("Guarantee rate (%)", fontsize=13)
    ax.set_ylabel(f"Mean annual generation ({unit}/yr)", fontsize=13)
    ax.tick_params(labelsize=11)
    ax.grid(True, alpha=0.25)
    ax.legend(frameon=False, fontsize=11, loc="best")
    fig.tight_layout()
    for suffix in ("png", "pdf"):
        fig.savefig(output / f"generation_reliability_tradeoff.{suffix}",
                    dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    return pd.DataFrame(highlighted)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outputs-root", type=Path)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--dqn-source", type=Path, help="DQN scan validation ZIP/directory, or final evaluation source")
    parser.add_argument("--dqn-split", choices=("validation", "evaluation"), default="validation")
    parser.add_argument("--dqn-error-bars", action="store_true", help="Show DQN seed sample SD")
    parser.add_argument("--check-only", action="store_true", help="Validate input tables without plotting or writing output")
    parser.add_argument("--without-dqn", action="store_true")
    parser.add_argument("--target", type=float, help="Reference line and classical post-hoc markers")
    parser.add_argument("--unit", choices=("GWh", "TWh"), default="TWh")
    parser.add_argument("--dpi", type=int, default=600)
    args = parser.parse_args()
    if args.target is not None and not 0 <= args.target <= 100:
        parser.error("--target must be in 0..100")
    if args.without_dqn and args.dqn_source is not None:
        parser.error("Use --without-dqn or --dqn-source, not both")
    project = Path(__file__).resolve().parents[1]
    outputs = (args.outputs_root or project / "outputs").resolve()
    hashes = expected_hashes(project)
    points = load_classical(outputs, hashes)
    dqn_source = None if args.without_dqn else find_dqn_source(outputs, args.dqn_source, args.dqn_split)
    dqn_seeds = None
    if dqn_source is not None:
        if args.dqn_split == "validation":
            dqn_points, dqn_seeds = load_dqn_validation(dqn_source)
        else:
            dqn_points, dqn_seeds = aggregate_dqn(read_dqn_records(dqn_source), hashes)
        points = pd.concat([points, dqn_points], ignore_index=True)
        print(f"DQN included: {len(dqn_points)} lambda points, {len(dqn_seeds)} seed results")
    else:
        print("DQN results not included; plotting DDP, SDP, ISO-SURF")
    print(points.groupby(["algorithm", "data_split"]).size().to_string())
    if args.check_only:
        print("DATA_CHECK_OK; plotting_not_run")
        return
    output = (args.output_dir or outputs / (
        "generation_reliability_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    )).resolve()
    output.mkdir(parents=True, exist_ok=False)
    highlights = draw(points, args.target, args.unit, args.dpi, output, args.dqn_error_bars)
    points.to_csv(output / "plot_points.csv", index=False, encoding="utf-8-sig")
    if not highlights.empty:
        highlights.to_csv(output / "classical_reference_points.csv", index=False,
                          encoding="utf-8-sig")
    if dqn_seeds is not None:
        dqn_seeds.to_csv(output / "dqn_seed_metrics.csv", index=False, encoding="utf-8-sig")
    protocol = {
        "x_axis": "guarantee_rate_pct",
        "y_axis": f"mean_annual_generation_{args.unit.lower()}",
        "evaluation_months": 4800,
        "data_hash": hashes[0], "physics_hash": hashes[1],
        "classical_source_root": str(outputs),
        "dqn_source": str(dqn_source) if dqn_source else None,
        "reference_target_pct": args.target,
        "classical_reference_selection": "posthoc_evaluation_nearest_target",
        "data_splits": points.groupby("algorithm")["data_split"].first().to_dict(),
        "dqn_months_per_seed": int(dqn_points["months_per_seed"].iloc[0]) if dqn_source else None,
        "dqn_selection": ("best validation checkpoint by penalized annual objective per lambda/seed"
                          if args.dqn_split == "validation" else "final evaluation checkpoint"),
        "dqn_aggregation": "mean of per-seed physical metrics; sample SD (ddof=1)",
        "dqn_error_bars": args.dqn_error_bars,
        "curve_connection": "lambda order; no smoothing or interpolation",
    }
    (output / "plot_protocol.json").write_text(
        json.dumps(protocol, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(points.groupby("algorithm").size().to_string())
    print(f"OUTPUT={output}")
    print("GENERATION_RELIABILITY_PLOT_OK")


if __name__ == "__main__":
    main()
